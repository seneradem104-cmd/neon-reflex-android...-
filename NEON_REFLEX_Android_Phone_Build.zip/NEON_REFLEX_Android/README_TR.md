# NEON REFLEX 5.2.1 — Android Projesi

Bu klasör, Android Studio ile açılabilen bir Android uygulama projesidir. Oyun, Android WebView içinde yerel `assets/index.html` dosyasından çalışır; internet bağlantısı gerektirmez.

## İçerik
- 3 şeritli, kaydırma kontrollü arcade oyun
- Easy / Normal / Hard
- Phantom / Cyber Ninja / Void karakter seçimi
- Neon Tokyo / Dark District / Synthetic City tema seçimi
- Tek can; süreli Shield ve Ghost koruması
- Shield, Slow, 2X, Ghost, Magnet güçlendirmeleri
- Shift Hunter: uyarı verir, sonra şerit değiştirir
- Üç boss saldırı davranışı
- Yerel en iyi skor ve kredi kaydı
- **Lazer engeli tamamen kaldırıldı**

## Android Studio ile APK oluşturma
1. ZIP dosyasını çıkar.
2. Android Studio'da **Open** seçip `NEON_REFLEX_Android` klasörünü aç.
3. Gradle senkronizasyonunun tamamlanmasını bekle. Android SDK Platform 36 ve JDK 17 gerekir.
4. Telefonda geliştirici seçenekleri / USB hata ayıklama açıksa Run ile test edebilirsin.
5. APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Play Store için: **Build > Generate Signed Bundle / APK > Android App Bundle** seçip imzalı `.aab` üret.

## Önemli
Bu teslimat Android Studio proje kaynaklarıdır; bu ZIP'in içinde önceden derlenmiş veya imzalanmış APK/AAB yoktur. Play Store'a yüklemeden önce uygulamayı gerçek cihazlarda test et, mağaza görsellerini, gizlilik politikasını ve Data safety beyanını hazırla.

## Yalnızca telefonla APK alma (GitHub Actions)
1. GitHub hesabı aç veya giriş yap: https://github.com
2. Yeni bir repository oluştur; adını `neon-reflex-android` yap ve **Public** seç.
3. ZIP'i telefonda çıkar. Proje içindeki dosya ve klasörleri (özellikle `.github` klasörünü de) repository'nin ana dizinine yükle. GitHub mobil web'de Add file > Upload files kullanılabilir.
4. `Actions` sekmesine gir. `Build Android APK` iş akışını açıp **Run workflow** seç.
5. İşlem tamamlanınca aynı iş akışının başarılı çalışmasına gir, **Artifacts** bölümündeki `NEON-REFLEX-debug-APK` dosyasını indir.
6. ZIP içindeki `app-debug.apk` dosyasını telefonda açıp kur. Android, ilk kurulumda tarayıcıya/dosya yöneticisine “bilinmeyen uygulama yükleme” izni isteyebilir.

Not: Bu debug APK test içindir; Play Store'a doğrudan yüklenmez. Play Store için ayrıca imzalı release AAB gerekir. GitHub deposunu Public yapmak istemezsen Private da kullanabilirsin; ücretsiz hesapta Actions dakika/kullanım sınırları geçerli olabilir.
